DELETE FROM guifragment WHERE code = 'test_widget';
DELETE FROM widgetcatalog WHERE code = 'test_widget';
